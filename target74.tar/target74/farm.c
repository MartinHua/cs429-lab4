/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_481(unsigned x)
{
    return x + 3284634440U;
}

unsigned addval_336(unsigned x)
{
    return x + 3267856712U;
}

unsigned addval_372(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_464(unsigned x)
{
    return x + 1304647901U;
}

unsigned addval_444(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_441(unsigned x)
{
    return x + 2417556097U;
}

unsigned getval_466()
{
    return 4213096792U;
}

unsigned getval_211()
{
    return 3281016832U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_174(unsigned *p)
{
    *p = 2464188744U;
}

void setval_496(unsigned *p)
{
    *p = 3229931145U;
}

unsigned addval_475(unsigned x)
{
    return x + 3531915657U;
}

unsigned addval_448(unsigned x)
{
    return x + 3286272840U;
}

void setval_313(unsigned *p)
{
    *p = 3375939977U;
}

unsigned addval_391(unsigned x)
{
    return x + 3222853257U;
}

void setval_440(unsigned *p)
{
    *p = 3281046153U;
}

void setval_377(unsigned *p)
{
    *p = 2425670281U;
}

unsigned addval_331(unsigned x)
{
    return x + 3531921033U;
}

unsigned addval_468(unsigned x)
{
    return x + 3373845129U;
}

void setval_439(unsigned *p)
{
    *p = 3526416009U;
}

unsigned getval_486()
{
    return 2428602479U;
}

void setval_135(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_222(unsigned x)
{
    return x + 3249139306U;
}

unsigned getval_489()
{
    return 549634441U;
}

unsigned getval_197()
{
    return 3223372233U;
}

unsigned addval_203(unsigned x)
{
    return x + 3286272456U;
}

unsigned getval_364()
{
    return 2430634056U;
}

unsigned getval_461()
{
    return 3221804553U;
}

unsigned addval_138(unsigned x)
{
    return x + 2915287435U;
}

unsigned getval_207()
{
    return 3685013129U;
}

unsigned getval_254()
{
    return 3674789512U;
}

void setval_167(unsigned *p)
{
    *p = 3675838089U;
}

unsigned getval_268()
{
    return 3531131529U;
}

unsigned getval_446()
{
    return 2447411528U;
}

unsigned addval_410(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_412()
{
    return 3380923016U;
}

unsigned getval_422()
{
    return 3252717896U;
}

unsigned getval_397()
{
    return 3351349568U;
}

void setval_194(unsigned *p)
{
    *p = 3677932185U;
}

unsigned addval_131(unsigned x)
{
    return x + 3224947337U;
}

void setval_385(unsigned *p)
{
    *p = 3372796555U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
